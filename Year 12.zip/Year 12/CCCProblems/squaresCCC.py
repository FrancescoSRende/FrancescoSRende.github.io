tiles = int(input("Number of tiles? "))
squares = int((tiles ** (1/2)) // 1)
print("The largest square has side length " + str(squares) + ".")